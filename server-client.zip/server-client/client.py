#coding utf-8


import os
import sys
import ConfigParser
import socket
#this is a client who collect information and send it to server 


def reader(path):
        con=os.popen("cat %s"%path)
        content = con.read()
        con.close()
        return content



def connect(cont):
        sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        sock.connect(("192.168.27.1",8001))
        sock.send(cont)
        sock.close()

def main():
        cfg = ConfigParser.ConfigParser()

      
if __name__== "__main__":
        

        config_path=os.path.join(os.path.dirname(__file__),"config.cfg")
        cfg=ConfigParser.ConfigParser()
        cfg.read(config_path)
        path_dict=dict(cfg.items("PATH_CONFIG"))

        print(path_dict)
        read_path =  path_dict["read_path"]
        path_list=path_dict["read_list"].split(",")
        for path in path_list:
                connect(reader(path))
-- ���� --                                                           33,1         �׶�

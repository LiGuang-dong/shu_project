function Result=Fisher(data)
clc;

load template pattern;
[pc_template,pc_data]=pcapro(data);  %���ɷַ���
temp=0;
for i=1:10
    pattern(1,i).feature=pc_template(:,temp+1:temp+pattern(1,i).num);
    temp=temp+pattern(1,i).num;
end

NumEnd=1;
for i=2:10
    NumEnd=FisherTwoClasses(NumEnd,i,data);
end

Result=NumEnd-1;

end

#coding utf-8  


#导入相应的包和模块
import smtplib         #发送邮件的协议
import os              #文件操作模块
from email.mime.text import MIMEText   #MIMEText 转化文字
from email.mime.multipart import MIMEMultipart    
from email import encoders
user = '18717876920@163.com'
pwd = 'Abc193777'
#to = ['1402598162@qq.com']
mailto_list=[]
a=input("请输入接收人的邮箱")
mailto_list.append(a)
msg = MIMEMultipart()
msg['From']='18717876920@163.com'
msg['Subject'] = '数据结构项目发送文件'
#msg['to']='1402598162@qq.com'
msg['To'] = ";".join(mailto_list) #收件人
content1 = MIMEText('这里是正文！', 'plain', 'utf-8')
msg.attach(content1)
#attfile ='D:\\test\\HTML.docx'
attfile=input("请输入上传文件的路径如D:\\test\\HTML.docx:")
#attfile = 'C:\\Users\\hengli\\Pictures\\CameraMan\\哈哈.doc'
basename = os.path.basename(attfile)
fp = open(attfile, 'rb')
att = MIMEText(fp.read(), 'plain', 'utf-8')
att["Content-Type"] = 'application/octet-stream'
att.add_header('Content-Disposition', 'attachment',filename=('gbk', '', basename))
encoders.encode_base64(att)
msg.attach(att)
#-----------------------------------------------------------
s = smtplib.SMTP('smtp.163.com')
s.login(user, pwd)      
s.sendmail(user, mailto_list, msg.as_string())

print('发送成功')
s.close()

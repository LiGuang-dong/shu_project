#coding=utf-8
import time
import MySQLdb
import matplotlib.pyplot as plt
import numpy as np

class Info:									#创建一个Info对象
	def __init__(self,passwd,host='127.0.0.1',user='root'):		
		self.conn=pymysql.connect(host,user,passwd,db='cient2')
		self.cur=self.conn.cursor()					
		


	def deal(self,data):							
		self.mem=data['mem']						
		self.times=data['times']
		self.names=data['name']
		self.onemin=data['one_min']
		self.fivemin=data['fivemin']	
		
	
	def insert_into_cpus(self):						#将获取的cpus的主机名和时间写入数据库
		sqls="insert into cpus value(%s,%s)"
		param=(self.names,self.times)
		self.cur.execute(sqls,param)
				

	def insert_into_mem(self):
		sqls="insert into mems value(%s,%s,%s)"				#将获取的mem,主机名和时间写入数据库
		param=(self.names,self.mem,self.times)
		self.cur.execute(sqls,param)
		
	def insert_into_loadavg(self):
		sqls="insert into loadavgs value(%s,%s,%s,%s)";
		param=(self.names,self.onemin,self.fivemin,self.times)	#将获取的负载的0,5分钟的时间,主机名,时间写入数据库
		self.cur.execute(sqls,param)


	def get_cpu_data(self,user):							#将数据的内容获取出来
		p=[]
		y=[]
		sqls="select idle from cpus where user=%s "
		param=(user)
		a=self.cur.execute(sqls,param)
		for row in self.cur.fetchall():
			l=list(row)
			p+=l
		for i in p:
			y.append(int(i))
		x=np.arange(0,a,1)
		plt.ylabel('idle')							
		plt.grid(True)
		plt.plot(x,y)
		plt.legend()	
		plt.title('CPUINFO')
	
	def get_mems_data(self,user):							#将内存从数据获取出(mem)
		p=[]
		y=[]
		sqls="select mem from mems where user=%s ";
		param=(user)
		a=self.cur.execute(sqls,param)
		for row in self.cur.fetchall():
			l=list(row)
			p+=l
		for i in p:
			y.append(int(i))
			x=np.arange(0,a,1)
		plt.ylabel('mem')							
		plt.grid(True)
		plt.plot(x,y)
		plt.title('MEMINFO')
	
	def get_loadavgs_data(self,user):						#将负载从数据库取出来
		p=[]
		y=[]
		sqls="select fivemin from loadavgs where user=%s ";
		param=(user)
		a=self.cur.execute(sqls,param)
		for row in self.cur.fetchall():						
			l=list(row)
			p+=l
		for i in p:
			y.append(int(i))
			x=np.arange(0,a,1)
		plt.ylabel('fivemin_load')						
		plt.grid(True)
		plt.plot(x,y)
		plt.title('LOADINFO')

	
	
	if __name__=="__main__":
		cur.close()
		conn.close()						
	








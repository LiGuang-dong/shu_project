#coding=utf-8
import os
import socket
import select
import json
from time import sleep
#from index import tables
from mysqlhelper import Info                         
import matplotlib.pyplot as plt    


	
info=Info('123')                                                      
sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM) 
sock.setblocking(False)                              
sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sock.bind(("192.168.3.130",8000))            	      	
sock.listen(5)
inputs=[sock]					     
outputs=[]
errputs=[]
 
while True:
	stdin,stdout,stderr=select.select(inputs,outputs,errputs,1)
	if stdin:				     
		for s in stdin:			     
			if s is sock:		    
				con,add=s.accept()   
				inputs.append(con)   
			else:
				data=s.recv(1024).decode('utf-8')
				if not data:
					inputs.remove(s)
				else:		     		  
					datas=json.loads(data)	  
					info.deal(datas)	  
					info.insert_into_cpus()   
					info.insert_into_mem()    
					info.insert_into_loadavg()
					plt.subplot(311)	  
					info.get_cpu_data('zhu2') 
					plt.subplot(312)	
					info.get_mems_data('zhu2')
					plt.subplot(313)	  
					info.get_loadavgs_data('zhu2')
					plt.show()		  
					sleep(1)		 	
					


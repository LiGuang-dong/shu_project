#coding:utf-8

import os
import sys
import time
import json
import threading
import SocketServer



path = "C:\test\1.txt.txt"
class MyHandle(SocketServer.StreamRequestHandler):
    def setup(self):
        print("%s:%s is connect"%self.client_address)
   

        self.have_file = os.path.exists(path)
        
    def hander(self):
       
        if self.have_file:
            name_split = path.rsplit(os.path.sep, 1)
            if len(name_split) > 1:
                file_name = name_split[1]
            else:
                file_name = name_split[0]
            hander = {
                "method":"put",
                "name": file_name,
                "size": os.path.getsize(path),
                "data": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
                "code": "utf-8"
            }
            json_data = json.dumps(hander)
            return json_data
        else:
            raise IOError("the file is not fond")
    def file_data(self,path):
        self.f = open(path,"rb")
        return self.f.read()
    def handle(self):
     
        data = self.request.recv(512)
        print(data)
        self.request.sendall(self.hander())
        while True:
            json_request = self.request.recv(128)
            print(json_request)
            print(type(json_request))

            requests = json.loads(json_request)
            print(requests)
            self.request.send("sssss")
       
    def finish(self):
   
        print("send is over")

class MyServer(SocketServer.ThreadingMixIn,SocketServer.TCPServer):
    pass




m = MyServer(("127.0.0.1",8888),MyHandle)

th = threading.Thread(target=m.serve_forever,args=())
th.start()
























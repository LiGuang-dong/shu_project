function num=FisherTwoClasses(num1,num2,data)
load template pattern;

m1=(mean(pattern(1,num1).feature'))';
m2=(mean(pattern(1,num2).feature'))';

s1=cov(pattern(1,num1).feature');
s2=cov(pattern(1,num2).feature');

sw=s1+s2;
sb=(m1-m2)*(m1-m2)';
w=inv(sw)*(m1-m2);

y1=w'*pattern(1,num1).feature;
y2=w'*pattern(1,num2).feature;

mean1=mean(y1');
mean2=mean(y2');

y0=(pattern(1,num1).num*mean1+pattern(1,num2).num*mean2)/(pattern(1,num1).num+pattern(1,num2).num);
    

y=w'*data';
if y>y0
    num=num1;
else
    num=num2;
end


end



















import os.path

assets = os.path.normpath(os.path.join(os.path.dirname(__file__), '../assets'))
